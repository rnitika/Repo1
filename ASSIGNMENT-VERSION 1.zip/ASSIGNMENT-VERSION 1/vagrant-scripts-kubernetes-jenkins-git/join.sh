kubeadm join 10.0.0.10:6443 --token iu7nij.sjejxvm7eo4gew17 --discovery-token-ca-cert-hash sha256:d77167788032abf18a89de30c400df541bf8be9a015cf50a7f90df0a7f3fb053 
